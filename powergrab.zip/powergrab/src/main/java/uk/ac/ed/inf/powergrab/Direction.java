package uk.ac.ed.inf.powergrab;

public enum Direction {
//public String N;
//public String W;
//public String E;
//public String S;
//public String NNE;
//public String NE;
//public String ENE;
//public String ESE;
//public String SE;
//public String SSE;
//public String SSW;
//public String SW;
//public String WSW;
//public String WNW;
//public String NW;
//public String NNW;
N,W,E,S,NNE,NE,ENE,ESE,SE,SSE,SSW,SW,WSW,WNW,NW,NNW;

}

